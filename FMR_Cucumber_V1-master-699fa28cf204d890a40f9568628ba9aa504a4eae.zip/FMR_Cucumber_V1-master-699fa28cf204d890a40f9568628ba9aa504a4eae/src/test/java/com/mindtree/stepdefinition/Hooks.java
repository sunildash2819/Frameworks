package com.mindtree.stepdefinition;
import org.apache.log4j.Logger;
import com.cucumber.listener.Reporter;
import com.mindtree.utility.ProgressBarUtility;
import com.mindtree.utility.ScreenshotUtility;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
/**
 * 
 * @author M1049131
 * Name : Sunil Kumar Dash
 * Description: This class describes the methods to be executed before and after each scenario
 * Date:30-12-2018
 */
public class Hooks {
	static Logger log=Logger.getLogger(Hooks.class);
	int progressbar_value=12;
	/*This method will execute before each scenario*/
	@Before
	public void beforeScenario(Scenario scenario)
	{
		Reporter.addScenarioLog(scenario.getName()+"->EXECUTION STARTED");
		log.info(scenario.getName()+" Execution is started");
	
	}
	/*This method will execute after each scenario*/
	@After
	public void afterScenario(Scenario scenario) throws Exception
	{
		Reporter.addScenarioLog(scenario.getName()+"->EXECUTION FINISHED");
		
		if(scenario.isFailed())
		{
			String scenarioName=scenario.getName();
			ScreenshotUtility.takeScreenshot(scenarioName);
			log.error(scenario.getName()+" Execution failed");	
		}
		else
		{
			log.trace(scenario.getName()+" Execution is passed");
		}
		ProgressBarUtility.inProgress(progressbar_value);
	}

}
