package com.mindtree.uistore;

import org.openqa.selenium.By;


/**
 * @author M1049200
 * Name: M. Lavanya
 * Description: This class contains the locators for user profile page objects
 * Date: 31-12-2018
 *
 */
public class UserProfileUistore {

	public static By login = By.xpath("//a[@href='#/login']");
	public static By click_email = By.xpath("//div[@class='md-form']");
	public static By email = By.xpath("//div[@class='md-form']//input[@id='loginformEmail']");
	public static By password = By.xpath("//div[@class='md-form']//input[@id='loginformPassword']");
	public static By signin = By.xpath("//button[@class='btn btn-default btn-info btn-block']");

	public static By Click_On_Name = By.xpath("//li[@class='nav-item dropdown']");
	public static By Click_On_Profile = By.xpath("//*[contains(text(), 'Profile')]");
	public static By My_profile = By.xpath("//a[@href='#/customerdashboard/profile']");
	
	public static By Change_Password=By.xpath("//a[@href='#/customerdashboard/changepassword']");
	public static By oldpassword=By.xpath("//input[@id='OLP']");
	public static By newpassword=By.xpath("//input[@id='NWP1']");
	public static By re_enterpw=By.xpath("//input[@id='NWP2']");
    public static By submit=By.xpath("//input[@type='submit']");
    public static By pwsuccess=By.xpath("//button[@class='swal-button swal-button--confirm']");
    
    public static By edit_Profile= By.xpath("//a[@href='#/customerdashboard/editProfile']");
    
    
    public static By bookinghistory=By.xpath("//a[@href='#/customerdashboard/bookingHistory']");
    
    
}
