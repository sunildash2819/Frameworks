package com.mindtree.uistore;

/**
 * @author M1049190
 * Name : Neeraja Chidambaram
 * Description : This class contains the locators of various web elements for home page objects and for pg and flat search.
 * Date : 31/12/2018 
 */
import org.openqa.selenium.By;

public class Homepageui {

	public static By selectcity=By.xpath("//select[@name='city']");
	public static By location=By.xpath("//input[@placeholder='Enter the location in the city..']");
	public static By buy=By.xpath("//label[@mdbradio='buy']");
	public static By flat=By.xpath("//label[@mdbradio='flat']");
	public static By button=By.xpath("//button[@type='submit']");
	public static By more=By.xpath("//a[@class='btn btn-info']");
	public static By ok=By.xpath("//button[@class='swal-button swal-button--confirm']");
	public static By rent=By.xpath("//label[@mdbradio='Rent']");
	public static By pg=By.xpath("//label[@mdbradio='pg']");

}
