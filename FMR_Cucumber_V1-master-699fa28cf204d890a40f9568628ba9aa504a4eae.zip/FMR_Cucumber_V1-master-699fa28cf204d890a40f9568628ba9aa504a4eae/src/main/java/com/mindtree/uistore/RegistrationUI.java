package com.mindtree.uistore;

import org.openqa.selenium.By;

/**
 * @author M1049109
 * Name: Swati Jha
 * Description: This class contains the locators of various web elements for user registration page objects
 * Date: 31-12-2018
 *
 */
public class RegistrationUI {
	public static By loginButton=By.xpath("//a[@href='#/login']");
	public static By register=By.xpath("//a[contains(text(),'Register')]");


	public static By customerToggle=By.xpath("//label[contains(text(),'Customer')]");


	public static By firstName=By.xpath("//input[@id='fName']");
	public static By lastName=By.xpath("//input[@id='lName']");

	public static By email=By.xpath("//input[@id='uEmail']");

	public static By password=By.xpath("//input[@id='uPassword']");
	public static By confirmPassword=By.xpath("//input[@id='uConfirm']");

	public static By phone=By.xpath("//input[@id='uPhone']");

	public static By userCity=By.xpath("//input[@formcontrolname='userCity']");
	public static By userStreet=By.xpath("//input[@id='uStreet']");
	public static By userPostalCode=By.xpath("//input[@id='uPostal']");


	public static By signUpButton=By.xpath("//div[@class='col-md-4']//button[contains(text(),'Sign up')]");
	
	public static By alreadyRegistered=By.xpath(("//div[contains(text(),'Already Registered')]"));

}
