package com.mindtree.reusuablecomponents;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mindtree.utility.PropertyConfigUtility;
/** 
 * @author M1049131
 * Name : Sunil Kumar Dash
 * Description: This class contains the methods for reusuable components 
 * Date:28-12-2018
 */
public class HelperClass {
	public static WebDriver driver;
	public static WebDriverWait wait;
	/*Method to open the browser and navigate to home page*/
	public static void openBrowserAndNavigateToURL()
	{
		System.setProperty("webdriver.chrome.driver",PropertyConfigUtility.prop.getProperty("driverPath"));
		  driver = new ChromeDriver();
		  driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		  driver.manage().window().maximize();
		 driver.get(PropertyConfigUtility.prop.getProperty("url"));
	}
	/*Method to close the browser*/
	public static void closeBrowser()
	{
		driver.quit();
	}

}
