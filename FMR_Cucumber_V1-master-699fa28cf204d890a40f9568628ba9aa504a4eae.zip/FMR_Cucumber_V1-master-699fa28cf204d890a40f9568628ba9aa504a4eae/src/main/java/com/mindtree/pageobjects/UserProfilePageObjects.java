package com.mindtree.pageobjects;

import java.awt.AWTException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.mindtree.reusuablecomponents.HelperClass;
import com.mindtree.uistore.UserProfileUistore;
import com.mindtree.utility.PropertyConfigUtility;

/**
 * @author M1049200
 * Name:M.Lavanya
 * Description:This class contains the page objects of user profile step definition
 * Date:31-12-2018
 */
public class UserProfilePageObjects {
	static Logger log=Logger.getLogger(UserProfilePageObjects.class);
	/*Method to open the browser and navigate to URL*/
	public static void login_FMR() {
		try
		{
		HelperClass.driver.findElement(UserProfileUistore.login).click();
		}catch(Exception e)
		{
		log.error(e);
		}
	}

	/*Method to login to the website Find my room*/
	public static void login( String username, String password) {
		try
		{
		HelperClass.driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		HelperClass.driver.findElement(UserProfileUistore.click_email).click();
		HelperClass.driver.findElement(UserProfileUistore.email).sendKeys(username);
		HelperClass.driver.findElement(UserProfileUistore.password).sendKeys(password);
		HelperClass.driver.findElement(UserProfileUistore.signin).click();
		}catch(Exception e)
		{
			log.error(e);
		}
		

	}

	/*Method to click on my profile*/
	public static void My_profile() {
		try
		{
		HelperClass.driver.findElement(UserProfileUistore.Click_On_Name).click();
		HelperClass.driver.findElement(UserProfileUistore.Click_On_Profile).click();
		HelperClass.driver.findElement(UserProfileUistore.My_profile).click();
		}catch(Exception e)
		{
			log.error(e);
		}
		

	}

	/*Method to click on change password*/
	public static void Click_changepw() {
		try
		{
		HelperClass.driver.findElement(UserProfileUistore.Change_Password).click();
		}catch(Exception e)
		{
			log.error(e);
		}
		
	}

	/*Method to change the password*/
	public static void Change_Password() {
        try
        {
		HelperClass.driver.findElement(UserProfileUistore.oldpassword).sendKeys(PropertyConfigUtility.prop.getProperty("oldpassword"));
		HelperClass.driver.findElement(UserProfileUistore.newpassword).sendKeys(PropertyConfigUtility.prop.getProperty("newpassword"));
		HelperClass.driver.findElement(UserProfileUistore.re_enterpw).sendKeys(PropertyConfigUtility.prop.getProperty("re_enterpassword"));
        }catch(Exception e)
        {
        	log.error(e);
        }
	}

	/*Method to click on submit after changing the password*/
	public static void submit() {
		try
		{
		HelperClass.driver.findElement(UserProfileUistore.submit).click();
		HelperClass.driver.findElement(UserProfileUistore.pwsuccess).click();
		HelperClass.driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		}catch(Exception e)
		{
			log.error(e);
		}
		
	}

	/*Method to edit the profile*/
	public static void edit_Profile() throws AWTException {
		try
		{
		HelperClass.driver.findElement(UserProfileUistore.edit_Profile).click();
		HelperClass.driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		}catch(Exception e)
		{
			log.error(e);
		}

		
	}

	/*Method to see the booking history*/
	public static void Booking_history() {
		try
		{
		HelperClass.driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		HelperClass.driver.findElement(UserProfileUistore.bookinghistory).click();
		HelperClass.driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		}catch(Exception e)
		{
			log.error(e);
		}

		
	}

}
