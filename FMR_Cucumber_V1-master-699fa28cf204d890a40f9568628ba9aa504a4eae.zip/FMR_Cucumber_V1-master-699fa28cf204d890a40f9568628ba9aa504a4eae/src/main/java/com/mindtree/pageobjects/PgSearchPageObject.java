package com.mindtree.pageobjects;


import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.mindtree.uistore.Homepageui;
/**
 * @author M1049190
 * Name : Neeraja Chidambaram
 * Description : This class describes the methods required for PG search
 * Date : 31/12/2018 
 */
public class PgSearchPageObject {
	static Logger log=Logger.getLogger(PgSearchPageObject.class);
	/*Method for PG Rent(positive flow)*/ 
	public static WebDriver clickRentandPg(WebDriver driver) {
		try
		{
		driver.findElement(Homepageui.rent).click();
		driver.findElement(Homepageui.pg).click();
		return driver;
		}catch(Exception e)
		{
			log.error(e);
		}
		return driver;
	}
	}
