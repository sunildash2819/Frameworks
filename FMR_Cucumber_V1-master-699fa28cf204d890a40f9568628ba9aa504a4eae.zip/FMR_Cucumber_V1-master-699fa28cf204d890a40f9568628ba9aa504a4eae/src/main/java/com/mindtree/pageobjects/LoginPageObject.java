package com.mindtree.pageobjects;

import java.util.concurrent.TimeUnit;
import com.mindtree.reusuablecomponents.HelperClass;
import com.mindtree.uistore.LoginPageUI;
/** 
 * @author M1049131
 * Name : Sunil Kumar Dash
 * Description: This class contains the page objects for the login page.
 * Date:28-12-2018
 */
public class LoginPageObject {
	/*Method to enter username*/
	public static boolean userNameField(String username)
	{
		try {
		HelperClass.driver.findElement(LoginPageUI.userNameFieldLocator).sendKeys(username);
		return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	/*Method to enter password*/
	public static boolean passwordField(String password)
	{
		try {
		HelperClass.driver.findElement(LoginPageUI.passwordFieldLocator).sendKeys(password);
		return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	/*Method to click on Forget Password button*/
	public static boolean clickOnForgetPassword()
	{
		try {
		HelperClass.driver.findElement(LoginPageUI.forgetPasswordLocator).click();
		return true;
		}
		catch (Exception e) {
			return false;
		}
		
	}
	/*Method to click on Sign in button*/
	public static boolean clickOnSignIn()
	{
		try {
		HelperClass.driver.findElement(LoginPageUI.signInButtonLocator).click();
		return true;
		}
		catch (Exception e) {
			return false;
		}
	}
	/*Method to enter username for forget password*/
	public static boolean enterUsername(String username) throws Exception
	{	
		HelperClass.driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		Thread.sleep(2000);
		try {
		HelperClass.driver.findElement(LoginPageUI.forgotPasswordusername).sendKeys(username);
		return true;
		}
		catch (Exception e) {
			return false;
		}
	}
	/*Method to click on submit button*/
	public static boolean clickOnSubmit()
	{
		try {
		HelperClass.driver.findElement(LoginPageUI.forgotPasswordSubmit).click();
		return true;
		}
		catch (Exception e) {
			return false;
		}
	}
}
