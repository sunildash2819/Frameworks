package com.mindtree.utility;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.swing.border.Border;

/**
 * @author M1049200
 * Name:M. Lavanya
 * Description: This class contains the utility of progress bar
 * Date:31-12-2018
 *
 */
public class ProgressBarUtility {
	
static JFrame frame = new JFrame("JProgressBar");
	
	static Container content = frame.getContentPane();
	static JProgressBar progressBar = new JProgressBar();
	static int val = 0;

	public static void inProgress(int value) {

		val = val + value;
		progressBar.setValue(val);
		progressBar.setStringPainted(true);
		Border border = BorderFactory.createTitledBorder("In progress");
		progressBar.setBorder(border);
		content.add(progressBar, BorderLayout.NORTH);
		frame.setSize(500, 300);
		frame.setVisible(true);

	}


}
