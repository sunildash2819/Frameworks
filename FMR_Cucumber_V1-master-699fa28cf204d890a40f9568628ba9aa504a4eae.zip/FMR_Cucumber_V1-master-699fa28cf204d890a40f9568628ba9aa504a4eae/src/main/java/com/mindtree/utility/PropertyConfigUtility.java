package com.mindtree.utility;

import java.io.FileInputStream;
import java.util.Properties;

/**
 * @author M1049131
 * Name:Sunil Dash
 * Description: This class contains the utility to read data from the property file
 * Date:29-12-2018
 *
 */
public class PropertyConfigUtility {
	public static Properties prop;
	
	/*Method to give path of property file and load it*/
	public void configProperty() throws Exception {

		String propFile="./config/configuration.properties";
		FileInputStream input=new FileInputStream(propFile);
		prop=new Properties(System.getProperties());
		prop.load(input);

	}
}	

