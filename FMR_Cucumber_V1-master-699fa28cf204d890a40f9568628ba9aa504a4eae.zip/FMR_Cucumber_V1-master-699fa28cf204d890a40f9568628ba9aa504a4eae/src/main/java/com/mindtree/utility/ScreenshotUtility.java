package com.mindtree.utility;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.cucumber.listener.Reporter;
import com.mindtree.reusuablecomponents.HelperClass;

/**
 * @author M1049109
 * Name:Swati Jha
 * Description: This class contains the utility to take the screenshot
 * Date:30-12-2018
 *
 */
public class ScreenshotUtility {
	
	/*Method to take the screenshot*/
	public static void takeScreenshot(String scenarioName) throws Exception
	{
		Date date=new Date();
		System.out.println(date);
		DateFormat dateFormat=new SimpleDateFormat("dd-MM-yyyy HH-mm-ss");
		
		String screenshotName=scenarioName+"_"+dateFormat.format(date);
		TakesScreenshot screenshot=(TakesScreenshot)HelperClass.driver;
		File sourcePath=screenshot.getScreenshotAs(OutputType.FILE);
		File destinationPath=new File(System.getProperty("user.dir")+"\\screenshot\\FMR_"+screenshotName+".png");
		FileUtils.copyFile(sourcePath, destinationPath);
		Reporter.addScreenCaptureFromPath(destinationPath.toString());	
	}

}

