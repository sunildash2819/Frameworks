package com.mindtree.utility;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

/**
 * @author M1049131
 * Name:Sunil Dash
 * Description: This class contains the utility to send mail
 * Date:29-12-2018
 *
 */
public class SendMailUtility {

	/*Method to send the mail*/
	public static void sendMail() throws Exception
	{
		PropertyConfigUtility.prop.put("mail.smtp.starttls.enable","true");
		PropertyConfigUtility.prop.put("mail.smtp.host",PropertyConfigUtility.prop.getProperty("host"));
		PropertyConfigUtility.prop.put("mail.smtp.user",PropertyConfigUtility.prop.getProperty("from"));
		PropertyConfigUtility.prop.put("mail.smtp.password",PropertyConfigUtility.prop.getProperty("password"));
		PropertyConfigUtility.prop.put("mail.smtp.port",PropertyConfigUtility.prop.getProperty("port"));
		PropertyConfigUtility.prop.put("mail.smtp.auth","true");
		
		Session session=Session.getInstance(PropertyConfigUtility.prop);
		Message message=new MimeMessage(session);
		message.setFrom(new InternetAddress(PropertyConfigUtility.prop.getProperty("from")));
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(PropertyConfigUtility.prop.getProperty("to")));
		message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(PropertyConfigUtility.prop.getProperty("cc")));
		
		message.setSubject("Report on FMR Test Execution");
		BodyPart messageBodyPart=new MimeBodyPart();
		messageBodyPart.setText("Sending an extent report on testing");
		
		MimeBodyPart messageBody=new MimeBodyPart();
		String filePath=PropertyConfigUtility.prop.getProperty("extentReportFilePath");
		DataSource source=new FileDataSource(filePath);
		
		messageBody.setDataHandler(new DataHandler(source));
		messageBody.setFileName(filePath);
		Multipart multipart = new MimeMultipart();
		multipart.addBodyPart(messageBody);
		message.setContent(multipart);
		
		Transport transport=session.getTransport("smtp");
		transport.connect(PropertyConfigUtility.prop.getProperty("host"),PropertyConfigUtility.prop.getProperty("from"),
																PropertyConfigUtility.prop.getProperty("password"));
		transport.sendMessage(message,message.getAllRecipients());
		
		System.out.println("----------------MAIL SENT--------------");
		
		transport.close();
			
	}
}
