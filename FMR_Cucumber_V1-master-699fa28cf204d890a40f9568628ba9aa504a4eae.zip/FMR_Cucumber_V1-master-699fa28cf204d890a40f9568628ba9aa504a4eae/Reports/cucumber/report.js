$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("LoginScenario.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 20,
  "name": "Login Feature",
  "description": "",
  "id": "login-feature",
  "keyword": "Feature",
  "tags": [
    {
      "line": 19,
      "name": "@Login"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.scenarioOutline({
  "line": 23,
  "name": "Login Test",
  "description": "",
  "id": "login-feature;login-test",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 22,
      "name": "@LoginTestScenario"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "I open the browser and navigate to home page",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "I click on login button and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "I enter \"\u003cusername\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I click on sign in button",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "The browser should be closed",
  "keyword": "And "
});
formatter.examples({
  "line": 30,
  "name": "",
  "description": "",
  "id": "login-feature;login-test;",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ],
      "line": 31,
      "id": "login-feature;login-test;;1"
    },
    {
      "cells": [
        "sunildash1908@yahoo.com",
        "Sunilk@12"
      ],
      "line": 32,
      "id": "login-feature;login-test;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 26256921,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "Login Test",
  "description": "",
  "id": "login-feature;login-test;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 19,
      "name": "@Login"
    },
    {
      "line": 22,
      "name": "@LoginTestScenario"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "I open the browser and navigate to home page",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "I click on login button and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "I enter \"sunildash1908@yahoo.com\" and \"Sunilk@12\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I click on sign in button",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "The browser should be closed",
  "keyword": "And "
});
formatter.match({
  "location": "LoginTestStepDefinition.i_open_the_browser_and_navigate_to_home_page()"
});
formatter.result({
  "duration": 11229139346,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestStepDefinition.i_click_on_login_button_and_go_to_login_page()"
});
formatter.result({
  "duration": 5221818983,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "sunildash1908@yahoo.com",
      "offset": 9
    },
    {
      "val": "Sunilk@12",
      "offset": 39
    }
  ],
  "location": "LoginTestStepDefinition.i_enter_and(String,String)"
});
formatter.result({
  "duration": 957622512,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestStepDefinition.i_click_on_sign_in_button()"
});
formatter.result({
  "duration": 3133046229,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestStepDefinition.the_browser_should_be_closed()"
});
formatter.result({
  "duration": 886764611,
  "status": "passed"
});
formatter.after({
  "duration": 330270547,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 36,
  "name": "Forget Password Test",
  "description": "",
  "id": "login-feature;forget-password-test",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 35,
      "name": "@ForgotPasswordTestScenario"
    }
  ]
});
formatter.step({
  "line": 37,
  "name": "I open the browser and navigate to home page",
  "keyword": "Given "
});
formatter.step({
  "line": 38,
  "name": "I click on login button and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 39,
  "name": "I click on forgot password",
  "keyword": "Then "
});
formatter.step({
  "line": 40,
  "name": "I enter my \"\u003cusername2\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "I click on submit button",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "The application should be closed",
  "keyword": "And "
});
formatter.examples({
  "line": 44,
  "name": "",
  "description": "",
  "id": "login-feature;forget-password-test;",
  "rows": [
    {
      "cells": [
        "username2"
      ],
      "line": 45,
      "id": "login-feature;forget-password-test;;1"
    },
    {
      "cells": [
        "bishal@mindtree.in"
      ],
      "line": 46,
      "id": "login-feature;forget-password-test;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 1393533,
  "status": "passed"
});
formatter.scenario({
  "line": 46,
  "name": "Forget Password Test",
  "description": "",
  "id": "login-feature;forget-password-test;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 19,
      "name": "@Login"
    },
    {
      "line": 35,
      "name": "@ForgotPasswordTestScenario"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.step({
  "line": 37,
  "name": "I open the browser and navigate to home page",
  "keyword": "Given "
});
formatter.step({
  "line": 38,
  "name": "I click on login button and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 39,
  "name": "I click on forgot password",
  "keyword": "Then "
});
formatter.step({
  "line": 40,
  "name": "I enter my \"bishal@mindtree.in\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "I click on submit button",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "The application should be closed",
  "keyword": "And "
});
formatter.match({
  "location": "LoginTestStepDefinition.i_open_the_browser_and_navigate_to_home_page()"
});
formatter.result({
  "duration": 19045848024,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestStepDefinition.i_click_on_login_button_and_go_to_login_page()"
});
formatter.result({
  "duration": 217829663,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestStepDefinition.i_click_on_forgot_password()"
});
formatter.result({
  "duration": 763716641,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "bishal@mindtree.in",
      "offset": 12
    }
  ],
  "location": "LoginTestStepDefinition.i_enter_my(String)"
});
formatter.result({
  "duration": 2426615124,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestStepDefinition.i_click_on_submit_button()"
});
formatter.result({
  "duration": 124430772,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestStepDefinition.the_application_should_be_closed()"
});
formatter.result({
  "duration": 889326807,
  "status": "passed"
});
formatter.after({
  "duration": 9299394,
  "status": "passed"
});
});