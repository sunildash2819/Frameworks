package com.mindtree.testScripts;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mindtree.base.BaseTest;
import com.mindtree.pageObject.AmazonHomePage;
import com.mindtree.pageObject.PasswordPage;
import com.mindtree.pageObject.SearchAndSelectItemPage;
import com.mindtree.pageObject.UserNamePage;

import com.mindtree.reusableComponents.HelperClass;
import com.mindtree.uistrore.PasswordPageUI;
import com.mindtree.utility.ExcelUtils;
//@Listeners(com.mindtree.utility.TestListener.class)
public class ExecuteScript6 extends BaseTest {
  
	static String itemName="";
	
	@Test(priority=0,groups= {"openBrowser"})
	public static void openBrowser() throws Exception
	{
		test=extent.createTest("Script-6:openBrowser");
		AmazonHomePage.openAmazonPage();
	}
	@Test(priority=1,groups= {"login"})
	public static void clickSignIn()
	{
		test=extent.createTest("Script-6:clickSignIn");
		boolean checkSignInButton=AmazonHomePage.clickSignIn();
		Assert.assertTrue(checkSignInButton);
		
	}
	@Test(priority=2,groups= {"login"})
	public static void enterUserName() 
	{
		test=extent.createTest("Script-6:enterUserName");
		String data=ExcelUtils.excelData.get("Username");
		boolean checkUsername=UserNamePage.UsernameInput(data);
		Assert.assertTrue(checkUsername);
		boolean nextButton=UserNamePage.clickContinue();
		Assert.assertTrue(nextButton);
	}
	@Test(priority=3,groups= {"login"})
	public static void enterPassword() 
	{
		test=extent.createTest("Script-6:enterPassword");
		String data=ExcelUtils.excelData.get("Password");
		boolean checkPassword=PasswordPage.PasswordInput(data);
		Assert.assertTrue(checkPassword);
		boolean submitButton=PasswordPage.clickSubmit();
		Assert.assertTrue(submitButton);
		HelperClass.driver.findElement(PasswordPageUI.skipLocator).click();
	}
	@Test(priority=4,groups= {"searchAndSelect"})
	public static void searchItem() 
	{
		test=extent.createTest("Script-6:searchItem");
		if(itemName.equalsIgnoreCase("") || itemName.equalsIgnoreCase("refrigerator"))
			itemName=ExcelUtils.excelData.get("searchItem1");
		else if(itemName.equalsIgnoreCase("mobiles"))
			itemName=ExcelUtils.excelData.get("searchItem2");
		boolean search=SearchAndSelectItemPage.searchItem(itemName);
		Assert.assertTrue(search);
		HelperClass.driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		HelperClass.closeBrowser();
	}
	
}
