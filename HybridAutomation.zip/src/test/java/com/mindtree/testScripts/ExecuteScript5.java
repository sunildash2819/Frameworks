package com.mindtree.testScripts;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mindtree.base.BaseTest;
import com.mindtree.pageObject.AddToCartPage;
import com.mindtree.pageObject.SearchAndSelectItemPage;

import com.mindtree.reusableComponents.HelperClass;
//@Listeners(com.mindtree.utility.TestListener.class)
public class ExecuteScript5 extends BaseTest {
  static String handle="";
 
	@Test(priority=2,groups= {"Select"})
	public static void selectItem()
	{
		test=extent.createTest("Script-5:selectItem");
		handle=HelperClass.driver.getWindowHandle();
		boolean select=SearchAndSelectItemPage.selectItem();
		Assert.assertTrue(select);
	}
	@Test(priority=3,groups= {"AddToCart"})
	public static void addToCart()
	{
		test=extent.createTest("Script-5:addToCart");
		for(String window:HelperClass.driver.getWindowHandles())
		{
			HelperClass.driver.switchTo().window(window);
		}
		boolean addCart=AddToCartPage.addItemToCart();
		Assert.assertTrue(addCart);
		HelperClass.driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		HelperClass.closeBrowser();
	}
}
