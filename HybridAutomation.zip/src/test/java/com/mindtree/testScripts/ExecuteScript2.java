package com.mindtree.testScripts;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mindtree.base.BaseTest;
import com.mindtree.pageObject.AmazonHomePage;
import com.mindtree.pageObject.SearchAndSelectItemPage;

import com.mindtree.reusableComponents.HelperClass;
import com.mindtree.utility.ExcelUtils;

//@Listeners(com.mindtree.utility.TestListener.class)
public class ExecuteScript2 extends BaseTest {
	
	static String handle="";
	static String itemName="";
	@Test(priority=0,groups= {"openBrowser"})
	public static void openBrowser() throws Exception
	{
		test=extent.createTest("Script-2:openBrowser");
		AmazonHomePage.openAmazonPage();
	}
	@Test(priority=1,groups= {"searchAndSelect"})
	public static void searchItem() 
	{
		test=extent.createTest("Script-2:searchItem");
		if(itemName.equalsIgnoreCase("") || itemName.equalsIgnoreCase("refrigerator"))
			itemName=ExcelUtils.excelData.get("searchItem1");
		else if(itemName.equalsIgnoreCase("mobiles"))
			itemName=ExcelUtils.excelData.get("searchItem2");
		boolean search=SearchAndSelectItemPage.searchItem(itemName);
		Assert.assertTrue(search);
	}
	@Test(priority=2,groups= {"searchAndSelect"})
	public static void selectItem()
	{
		test=extent.createTest("Script-2:selectItem");
		handle=HelperClass.driver.getWindowHandle();
		boolean select=SearchAndSelectItemPage.selectItem();
		Assert.assertTrue(select);
		HelperClass.driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		HelperClass.closeBrowser();
	}
}
