package com.mindtree.utility;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyConfig {

	public static Properties prop;
	public void configProperty() throws Exception {

	String propFile="./config/configuration.properties";
	FileInputStream input=new FileInputStream(propFile);
	prop=new Properties(System.getProperties());
	prop.load(input);
}
}
