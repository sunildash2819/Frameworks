package com.mindtree.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
	
	public static XSSFSheet ExcelWSheet;
	public static XSSFWorkbook ExcelWBook;
	public static XSSFCell Cell;
	public static  HashMap<String, String> excelData=new HashMap<>();
	public static void setExcelFile(String Path,String SheetName) throws IOException
	{
		 FileInputStream ExcelFile = new FileInputStream(new File(Path));
         ExcelWBook = new XSSFWorkbook(ExcelFile);
         ExcelWSheet = ExcelWBook.getSheet(SheetName);
	}
	
	 public static String getCellData(int RowNum, int ColNum) throws Exception{
		 Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
         String CellData = Cell.getStringCellValue();
         return CellData;
      
	 }
	 public static void storeExcelData() throws Exception
	 {
		 String key="";
		 String value="";
		 for(int i=1;i<ExcelWSheet.getLastRowNum();i++)
		 {
			 key=getCellData(i,1);
			 value=getCellData(i,2);
			 excelData.put(key,value);
		 }
	 }
}
