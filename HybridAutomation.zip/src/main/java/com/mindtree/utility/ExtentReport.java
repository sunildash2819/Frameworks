package com.mindtree.utility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReport {
	public static ExtentHtmlReporter reporter=new ExtentHtmlReporter("./TestReport/Tests_Execution_Report.html");
	public static ExtentReports extent;
	public static ExtentTest test;
	public static PropertyConfig property=new PropertyConfig();
	public static void run() throws Exception 
	{	
		property.configProperty();
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}


}
