package com.mindtree.uistrore;

import org.openqa.selenium.By;

public class HomePageUI {
	public static By signInLocator=By.xpath("//span[@class='nav-line-2']");
	public static By searchTextBox=By.id("twotabsearchtextbox");
	public static By searchButton=By.xpath("//input[@class='nav-input']");
	public static By popUpWindowLocator=By.xpath("//span[@class='a-button a-button-primary a-button-span12']");


}
