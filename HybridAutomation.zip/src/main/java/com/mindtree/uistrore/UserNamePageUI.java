package com.mindtree.uistrore;

import org.openqa.selenium.By;

public class UserNamePageUI {
	public static By usenameTextLocator=By.xpath("//input[@id='ap_email']");
	public static By usernameContinueLocator=By.xpath("//input[@id='continue']");

}
