package com.mindtree.uistrore;

import org.openqa.selenium.By;

public class PasswordPageUI {
	public static By passwordTextLocator=By.xpath("//input[@id='ap_password']");
	public static By passwordSubmitLocator=By.xpath("//input[@id='signInSubmit']");
	public static By skipLocator=By.id("ap-account-fixup-phone-skip-link");

}
