package com.mindtree.uistrore;

import org.openqa.selenium.By;

public class SelectItemPageUI {
	public static By itemLocator=By.xpath("//li[@id='result_3']"+
			"//div[@class='a-row a-spacing-mini']//div[@class='a-row a-spacing-none']" + 
			"//a[@class='a-link-normal s-access-detail-page  s-color-twister-title-link a-text-normal']");

}
