package com.mindtree.uistrore;

import org.openqa.selenium.By;

public class AddToCartPageUI {
	public static By addToCartLocator=By.xpath("//input[@id='add-to-cart-button']");
	public static By proceedToCheckOutLocator=By.xpath("//span[@class='a-button a-button-primary hlb-checkout-button huc-v2-"
			+ "primary-button  huc-button-large']");

}
