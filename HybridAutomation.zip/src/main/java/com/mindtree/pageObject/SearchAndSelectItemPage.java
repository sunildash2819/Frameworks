package com.mindtree.pageObject;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import com.mindtree.reusableComponents.HelperClass;
import com.mindtree.uistrore.SelectItemPageUI;

public class SearchAndSelectItemPage {
	public static boolean searchItem(String itemName)
	{
		WebElement searchBox=AmazonHomePage.searchBox();
		searchBox.clear();
		Actions action=new Actions(HelperClass.driver);
		Action keyEvent=action.moveToElement(searchBox).click().keyDown(searchBox, Keys.SHIFT).sendKeys(itemName)
				.keyUp(searchBox, Keys.SHIFT).build();
		keyEvent.perform();
		AmazonHomePage.clickSearchButton();
		return true;
	}
	public static boolean selectItem()
	{
		HelperClass.driver.findElement(SelectItemPageUI.itemLocator).click();
		return true;
	}

}
