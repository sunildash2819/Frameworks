package com.mindtree.pageObject;

import com.mindtree.reusableComponents.HelperClass;
import com.mindtree.uistrore.UserNamePageUI;


public class UserNamePage {

	public static boolean UsernameInput(String data)
	{
		HelperClass.driver.findElement(UserNamePageUI.usenameTextLocator).clear();
		HelperClass.driver.findElement(UserNamePageUI.usenameTextLocator).sendKeys(data);
		return true;
	}
	public static boolean clickContinue()
	{
		HelperClass.driver.findElement(UserNamePageUI.usernameContinueLocator).click();
		return true;
	}
}
