package com.mindtree.pageObject;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.mindtree.reusableComponents.HelperClass;
import com.mindtree.uistrore.HomePageUI;

public class AmazonHomePage {
	public static void openAmazonPage() throws Exception
	{
		HelperClass.openBrowserAndNavigateToUrl();
	}
	public static boolean clickSignIn()
	{
		HelperClass.driver.findElement(HomePageUI.signInLocator).click();
		
		return true;
	}
	public static WebElement searchBox()
	{
		return HelperClass.driver.findElement(HomePageUI.searchTextBox);
	}
	public static void clickSearchButton()
	{
		HelperClass.driver.findElement(HomePageUI.searchButton).click();
	}
	/*public static void handlePopUpWindow()
	{
		String mainWindow=HelperClass.driver.getWindowHandle();
		String subWindow="";
		Set<String> handles = HelperClass.driver.getWindowHandles(); 
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()){
		    subWindow = iterator.next();
		}
		HelperClass.driver.switchTo().window(subWindow);
		HelperClass.driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement waitForSiginin=HelperClass.wait.until(ExpectedConditions.elementToBeClickable(HomePageUI.popUpWindowLocator));
		waitForSiginin.click();
		HelperClass.driver.switchTo().window(mainWindow);
	}*/
	
	
	

}








