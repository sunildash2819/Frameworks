package com.mindtree.pageObject;

import com.mindtree.reusableComponents.HelperClass;
import com.mindtree.uistrore.AddToCartPageUI;

public class AddToCartPage {
	public static boolean addItemToCart()
	{
		HelperClass.driver.findElement(AddToCartPageUI.addToCartLocator).click();
		return true;
	}
	public static boolean proceedToCheckOut()
	{
		HelperClass.driver.findElement(AddToCartPageUI.proceedToCheckOutLocator).click();
		return true;
	}

}
