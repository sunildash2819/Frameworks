package com.mindtree.pageObject;

import com.mindtree.reusableComponents.HelperClass;
import com.mindtree.uistrore.PasswordPageUI;

public class PasswordPage {

	public static boolean PasswordInput(String data)
	{
		 HelperClass.driver.findElement(PasswordPageUI.passwordTextLocator).clear();
		 HelperClass.driver.findElement(PasswordPageUI.passwordTextLocator).sendKeys(data);
		 return true;
	}
	public static boolean clickSubmit()
	{
		HelperClass.driver.findElement(PasswordPageUI.passwordSubmitLocator).click();
		return true;
	}
}
