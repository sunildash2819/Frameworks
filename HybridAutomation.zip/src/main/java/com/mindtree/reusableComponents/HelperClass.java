package com.mindtree.reusableComponents;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mindtree.utility.ExcelUtils;
import com.mindtree.utility.PropertyConfig;

public class HelperClass {
	public static WebDriver driver;
	public static WebDriverWait wait;
	public static PropertyConfig property=new PropertyConfig();
	
	public static void openBrowserAndNavigateToUrl() throws Exception
	{
		property.configProperty();
		  ExcelUtils.setExcelFile(PropertyConfig.prop.getProperty("excelFilePath"), PropertyConfig.prop.getProperty("excelSheet"));
		  ExcelUtils.storeExcelData();
		  System.setProperty("webdriver.chrome.driver",PropertyConfig.prop.getProperty("driverPath"));
		  driver = new ChromeDriver();
		  driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		  driver.manage().window().maximize();
		  driver.get(PropertyConfig.prop.getProperty("url"));
	}
	
	public static void closeBrowser()
	{
		driver.quit();
	}

	public static void navigateToHomePage()
	{
		HelperClass.driver.get(PropertyConfig.prop.getProperty("url"));
	}

}
